from menu import *
from Creation_BD import *

__all__ = ['etudiant',"enseignant","formation","groupe","module","sessionFormation","personne","menuapp"]



if __name__ == '__main__':
    m = menuapp.menu()