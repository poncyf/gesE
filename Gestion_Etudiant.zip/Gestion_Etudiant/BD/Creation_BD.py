import sqlite3
import random
import os
from menu import *
 

# création d'un objet connection
con = sqlite3.connect("SupTempo")
# création d'un objet curseur

c = con.cursor()
# création d'un objet curseur
c = con.cursor()


class etudiant(object):

    def __init__(self, Numetudiant, prenom, nom, dateNaiss, lieunaiss, adresseEtud, tel, email, numPiece, designation):
        self.numPiece = numPiece
        self.email = email
        self.tel = tel
        self.adresseEtud = adresseEtud
        self.lieunaiss = lieunaiss
        self.Numetudiant = Numetudiant
        self.prenom = prenom
        self.designation = designation
        self.dateNaiss = dateNaiss
        self.Numetudiant = Numetudiant

#Affichage de tous les etudiants
    def afficheetudiant():
        c.execute("SELECT * FROM etudiant")
        for resultat in c:
            print(resultat)

#Enregistrement des etudiants
    def enregetudiant():
        nom = input("Nom de l'etudiant : ")
        Numetudiant = None
        designation = input("Formation souhaitée :")
        prenom = input("Prenom de l'etudiant : ")
        email = input("Mail : ")
        numPiece = input("Numero de votre piece d'etudiant : ")
        adresseEtud = input("Adresse : ")
        tel = input("Numero de telephone : ")
        dateNaiss = input("Date de naissance :")
        lieunaiss = input("Lieu naissance")
        c.execute(
            "INSERT INTO etudiant (prenom,nom,dateNaiss,lieunaiss,adresseEtud,tel,email,numPiece,designation) VALUES(?,?,?,?,?,?,?,?,?)",
            (prenom, nom, dateNaiss, lieunaiss, adresseEtud, tel, email, numPiece, designation))
        con.commit()
        c.close()
        con.close()
        et = etudiant.afficheetudiant()
        m = menuapp.menu()

#Méthode pour modifier les données d'un etudiant
    def modifetudiant(): 
        Numetudiant = etudiant.rechetudiant()

        print(" Modification des données d'un etudiant : ")
        print(" Option 1 ==> Nom")
        print(" Option 2 ==> Prenom")
        print(" Option 3 ==> Email")
        print(" Option 4 ==> Lieu de naissance")
        print(" Option 5 ==> Adresse")
        print(" Option 6 ==> Telephone")
        print(" Option 7 ==> Date Naissance")

        while True:
            option = int(input("Choisissez une option ci-dessus. "))
            if option > 7:
                print ("Veuillez choisir de 1 à 7")
            
            elif option == 1:
             
                print("Nom actuel de l'etudiant : ") 
                c.execute("SELECT nom FROM etudiant WHERE Numetudiant = ?", (Numetudiant, ))
                print(c.fetchone())
                # confirmer()
                nouv = input("Entrez le nouveau nom : ")
                c.execute(""" UPDATE etudiant SET nom = ? WHERE Numetudiant = ? """, (nouv, Numetudiant, ))
                con.commit()
                print("Modification réussie, veuillez vérifier ci-dessous.")
                c.execute("SELECT * FROM etudiant WHERE Numetudiant = ?", (Numetudiant, ))
                print(c.fetchone())
                c.close()
                con.close()

            elif option == 2:
                print("Prenom actuel de l'etudiant : ") 
                c.execute("SELECT prenom FROM etudiant WHERE Numetudiant = ?", (Numetudiant, ))
                print(c.fetchone())
                # confirmer()
                nouv = input("Entrez le nouveau prenom  de l'etudiant: ")
                c.execute(""" UPDATE etudiant SET prenom = ? WHERE Numetudiant = ? """, (nouv, Numetudiant, ))
                con.commit()
                print("modification réussie, veuillez vérifier ci-dessous.")
                c.execute("SELECT * FROM etudiant WHERE Numetudiant = ?", (Numetudiant, ))
                print(c.fetchone())
                c.close()
                con.close()
            
            
            elif option == 3:
                print("Email actuel de ce client : ") 
                c.execute("SELECT email FROM etudiant WHERE Numetudiant = ?", (Numetudiant, ))
                print(c.fetchone())
                # confirmer()
                nouv = input("Entrez le nouvel mail  du client: ")
                c.execute(""" UPDATE etudiant SET email = ? WHERE Numetudiant = ? """, (nouv, Numetudiant, ))
                con.commit()
                print("Modification réussie, veuillez vérifier ci-dessous.")
                c.execute("SELECT * FROM etudiant WHERE Numetudiant = ?", (Numetudiant, ))
                print(c.fetchone())
                c.close()
                con.close()
                
            elif option == 4:
                print("Voici le lieu de naissance actuel de l'etudiant : ")
                c.execute("SELECT lieunaiss FROM etudiant WHERE Numetudiant = ?", (Numetudiant, ))
                print(c.fetchone())
                # confirmer()
                nouv = input(" Entrez le nouveau lieu de naissance de l'etudiant : ")
                c.execute(""" UPDATE etudiant SET lieunaiss = ? WHERE Numetudiant = ? """, (nouv, Numetudiant, ))
                con.commit()
                print("modification réussie, veuillez vérifier ci-dessous.")
                c.execute("SELECT * FROM etudiant WHERE Numetudiant = ?", (Numetudiant, ))
                print(c.fetchone())
                c.close()
                con.close()

            elif option == 5:
                print("Voici l'adresse actuelle de l'etudiant : ")
                c.execute("SELECT adresseEtud FROM etudiant WHERE Numetudiant = ?", (Numetudiant, ))
                print(c.fetchone())
                # confirmer()
                nouv = input("Entrez le nouvel adresse  de l'etudiant: ")
                c.execute(""" UPDATE etudiant SET adresseEtud = ? WHERE Numetudiant = ? """, (nouv, Numetudiant, ))
                con.commit()
                print("modification réussie, veuillez vérifier ci-dessous.")
                c.execute("SELECT * FROM etudiant WHERE Numetudiant = ?", (Numetudiant, ))
                print(c.fetchone())
                c.close()
                con.close()


            elif option == 6:
                print("Voici le numero de telephone de l'etudiant : ")
                c.execute("SELECT tel FROM etudiant WHERE Numetudiant = ?", (Numetudiant, ))
                print(c.fetchone())
                # confirmer()
                nouv = input("Entrez le nouvo numero de telephone  : ")
                c.execute(""" UPDATE etudiant SET tel = ? WHERE Numetudiant = ? """, (nouv, Numetudiant, ))
                con.commit()
                print("modification réussie, veuillez vérifier ci-dessous.")
                c.execute("SELECT * FROM etudiant WHERE Numetudiant = ?", (Numetudiant, ))
                print(c.fetchone())
                c.close()
                con.close()


            elif option == 7:
                print("Voici la date de naissance de l'etudiant : ")
                c.execute("SELECT dateNaiss FROM etudiant WHERE Numetudiant = ?", (Numetudiant, ))
                print(c.fetchone())
                # confirmer()
                nouv = input(" Entrez la nouvelle date de naissance : ")
                c.execute(""" UPDATE etudiant SET dateNaiss = ? WHERE Numetudiant = ? """, (nouv, Numetudiant, ))
                con.commit()
                print("modification réussie, veuillez vérifier ci-dessous.")
                c.execute("SELECT * FROM etudiant WHERE Numetudiant = ?", (Numetudiant, ))
                print(c.fetchone())
                c.close()
                con.close()
            else:
                break
            
#Méthode pour rechercher un etudiant
    def rechetudiant(): 
        
            rech = input("entrer le nom d'un etudiant pour le rechercher : ")
            req = c.execute("SELECT * FROM etudiant WHERE nom= ? ", (rech, ))
            req = c.fetchone()
            print(c.fetchone())
            while req == None:
                print("Cette etudiant n'existe pas")
                rech = input("entrer le nom d'un etudiant pour le rechercher : ")
                req = c.execute("SELECT * FROM etudiant WHERE nom= ? ", (rech, ))
                if req != None:
                    for row in req.fetchall():
                        print(row)
                    Numetudiant = int(input("Veuillez entrer l'ID de l'etudiant que vous recherchez: "))
                    c.execute("SELECT * FROM etudiant WHERE Numetudiant=? ",(Numetudiant, ))
                    return Numetudiant
                
#Méthode pour supprimer un etudiant
    def suppretudiant(): 
        try:
            Numetudiant = etudiant.rechetudiant()
            print("est-ce ce l'etudiant que vous voulez supprimer ?  ")
            c.execute("SELECT * FROM etudiant WHERE Numetudiant = ?", (Numetudiant, ))
            print(c.fetchone())
            c.execute(""" DELETE from etudiant WHERE Numetudiant = ? """, (Numetudiant, ))
            con.commit()
            print("supression réussie, veuillez vérifier ci-dessous.")
            c.close()
            con.close()
            
        except Exception as e:
            print("[ERREUR]",e)
            con.rollback()

class personne(etudiant):

    def __init__(self,nompers, prenompers, telPersonne, emailpers, pays, lienFamille,Numetudiant):
        self.nompers = nompers
        self.prenompers = prenompers
        self.telPersonne = telPersonne
        self.emailpers = emailpers
        self.pays = pays
        self.lienFamille = lienFamille
        self.Numetudiant = Numetudiant

    def affichepersonne():
        c.execute("SELECT * FROM personneContacter")
        for resultat in c:
            print(resultat)

    def enregpersonne():
        nompers = input("nom de la personne a contacter ")
        prenompers = input("prenom de la personne a contacter")
        telPersonne = input("telephone de la personne a contacter")
        emailpers = input("email de la personne a contacter")
        lienFamille = input("lien de famille ")
        Numetudiant = input("entrez l'ID de l'etudiant concerner")
        pays = input("pays de residence de la personne a contacter")
        c.execute(
            "INSERT INTO personneContacter (nompers,prenompers,telPersonne,emailpers,pays,lienFamille,Numetudiant) VALUES(?,?,?,?,?,?,?)",
            (nompers, prenompers, telPersonne, emailpers, pays, lienFamille,Numetudiant))
        con.commit()
        c.close()
        con.close()
        m = menuapp.menu()

#Méthode pour rechercher un etudiant        
    def rechepersonne(): 
        rech = input("entrer le nom de la personne a contacter qui corespond a l'etudiant que vous cherchez  : ")
        c.execute("SELECT * FROM personneContacter WHERE nompers= ? ", (rech, ))
        print(c.fetchall())
        idPersonne = int(input("Veuillez entrer l'ID de la personne dont vous voulez faire un mise a jour ou supprimer : "))
        c.execute("SELECT * FROM personneContacter WHERE idPersonne=? ",(idPersonne, ))
        return idPersonne

#Méthode pour supprimer une personne a contacter
    def supprpersonne(): 
        idPersonne =personne.rechepersonne()
        print("est-ce ce la personne que vous voulez supprimer ?  ")
        c.execute("SELECT * FROM personneContacter  WHERE idPersonne = ?", (idPersonne, ))
        print(c.fetchone())
        c.execute(""" DELETE from personneContacter WHERE idPersonne = ? """, (idPersonne, ))
        con.commit()
        print("supression réussie, veuillez vérifier ci-dessous.")
        c.close()
        con.close()
        m = menuapp.menu()
        
class enseignant():

    def __init__(self,numEnseign,nomPrenom,dateNaiss,lieuNaiss,nationalite, adresse, tel,email,skype,linkind,diplome,anneeExperience,specialite,competence):
        self.nomPrenom = nomPrenom
        self.dateNaiss = dateNaiss
        self.lieuNaiss = lieuNaiss
        self.adresse = adresse
        self.tel = tel
        self.email = email
        self.skype = skype
        self.linkind = linkind
        self.diplome = diplome
        self.anneeExperience = anneeExperience
        self.specialite = specialite
        self.competence = competence
        self.nationalite = nationalite
        self.numEnseign = numEnseign

    def afficheenseignant():
        c.execute("SELECT * FROM enseignant")
        for resultat in c:
            print(resultat)
       
#Méthode pour modifier les données d'un enseignant
    def modifeignant(): 
        numEnseign = enseignant.recheenseignant()

        print(" voici les différentes options de modification des données d'un etudiant : ")
        print(" Option 1 ==> nom et prenom")
        print(" Option 2 ==> email")
        print(" Option 3 ==> lieu de naissance")
        print(" Option 4 ==> adresse")
        print(" Option 5 ==> telephone")
        print(" Option 6 ==> date Naissance")

        while True:
            option = int(input("Choisissez une option parmis celles ci-dessus. "))
            if option > 7:
                print ("Veuillez choisir parmi les options listées de 1 à 7")
            
            elif option == 1:
             
                print("Voici le nom et le prenom actuel de l'enseignant : ") 
                c.execute("SELECT nomPrenom FROM enseignant WHERE numEnseign = ?", (numEnseign, ))
                print(c.fetchone())
                # confirmer()
                nouv = input("Entrez le nouveau nom et prenom  de l'enseignant : ")
                c.execute(""" UPDATE enseignant SET nomPrenom = ? WHERE numEnseign = ? """, (nouv, numEnseign, ))
                con.commit()
                print("modification réussie, veuillez vérifier ci-dessous.")
                c.execute("SELECT * FROM enseignant WHERE numEnseign = ?", (numEnseign, ))
                print(c.fetchone())
                c.close()
                con.close()
                break
            
            elif option == 2:
                print("Voici l'email actuel de ce l'enseignant : ") 
                c.execute("SELECT email FROM enseignant WHERE numEnseign = ?", (numEnseign, ))
                print(c.fetchone())
                # confirmer()
                nouv = input("Entrez le nouvel email  du l'enseignant: ")
                c.execute(""" UPDATE enseignant SET email = ? WHERE numEnseign = ? """, (nouv, numEnseign, ))
                con.commit()
                print("modification réussie, veuillez vérifier ci-dessous.")
                c.execute("SELECT * FROM enseignant WHERE numEnseign = ?", (numEnseign, ))
                print(c.fetchone())
                c.close()
                con.close()
                break
            elif option == 3:
                print("Voici le lieu de naissance actuel de l'enseignant : ")
                c.execute("SELECT lieuNaiss FROM enseignant WHERE numEnseign = ?", (numEnseign, ))
                print(c.fetchone())
                # confirmer()
                nouv = input(" Entrez le nouveau lieu de naissance de l'enseignant : ")
                c.execute(""" UPDATE enseignant SET lieuNaiss = ? WHERE numEnseign = ? """, (nouv, numEnseign, ))
                con.commit()
                print("modification réussie, veuillez vérifier ci-dessous.")
                c.execute("SELECT * FROM enseignant WHERE numEnseign = ?", (numEnseign, ))
                print(c.fetchone())
                c.close()
                con.close()
                break


            elif option == 4:
                print("Voici l'adresse actuelle de l'enseignant : ")
                c.execute("SELECT adresse FROM enseignant WHERE numEnseign = ?", (numEnseign, ))
                print(c.fetchone())
                # confirmer()
                nouv = input("Entrez le nouvel adresse  de l'enseignant: ")
                c.execute(""" UPDATE enseignant SET adresse = ? WHERE numEnseign = ? """, (nouv, numEnseign, ))
                con.commit()
                print("modification réussie, veuillez vérifier ci-dessous.")
                c.execute("SELECT * FROM enseignant WHERE numEnseign = ?", (numEnseign, ))
                print(c.fetchone())
                c.close()
                con.close()
                break

            elif option == 5:
                print("Voici le numero de telephone de l'enseignant : ")
                c.execute("SELECT tel FROM enseignant WHERE numEnseign = ?", (numEnseign, ))
                print(c.fetchone())
                # confirmer()
                nouv = input("Entrez le nouvo numero de telephone  : ")
                c.execute(""" UPDATE enseignant SET tel = ? WHERE numEnseign = ? """, (nouv, numEnseign, ))
                con.commit()
                print("modification réussie, veuillez vérifier ci-dessous.")
                c.execute("SELECT * FROM enseignant WHERE numEnseign = ?", (numEnseign, ))
                print(c.fetchone())
                c.close()
                con.close()
                break
                

            elif option == 6:
                print("Voici la date de naissance de l'enseignant : ")
                c.execute("SELECT dateNaiss FROM enseignant WHERE numEnseign = ?", (numEnseign, ))
                print(c.fetchone())
                # confirmer()
                nouv = input(" Entrez la nouvelle date de naissance : ")
                c.execute(""" UPDATE enseignant SET dateNaiss = ? WHERE numEnseign = ? """, (nouv, numEnseign, ))
                con.commit()
                print("modification réussie, veuillez vérifier ci-dessous.")
                c.execute("SELECT * FROM enseignant WHERE numEnseign = ?", (numEnseign, ))
                print(c.fetchone())
                c.close()
                con.close()
            else:
                break

    def enregenseignant():
        numEnseign = None
        nomPrenom = input("nom de l'enseignant: ")
        dateNaiss = input("date naissance de l'enseignant :")
        lieuNaiss = input("lieu de naissance de l'enseignant :")
        nationalite = input("nationalite de l'enseignant :")
        adresse = input("rentrez l'adresse de l'enseignant :")
        tel = input("telephone :")
        email = input("adresse email : ")
        skype = input("adresse skype : ")
        linkind = input("adresse linkind : ")
        diplome = input("diplome de l'enseignant : ")
        anneeExperience = input("nombre d'annee d'experience : ")
        specialite = input("specialite de l'enseignant : ")
        competence = input("competence de l'enseignant : ")
        
        c.execute(
            "INSERT INTO enseignant (nomPrenom,dateNaiss,lieuNaiss,nationalite, adresse, tel,email,skype,linkind,diplome,anneeExperience,specialite,competence) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (nomPrenom,dateNaiss,lieuNaiss,nationalite, adresse, tel,email,skype,linkind,diplome,anneeExperience,specialite,competence))
        con.commit()
        c.close()
        con.close()

#Méthode pour rechercher un enseignant
    def recheenseignant(): 
        rechercher = input("entrer le nom de l'enseignant que rechercher : ")
        req = c.execute("SELECT * FROM enseignant WHERE nomPrenom= ? ", (rechercher, ))
        req = c.fetchone()
        print(c.fetchall())
        while req == None:
            print("Cette enseignant n'existe pas")
            rechercher = input("entrer le nom de l'enseignant que vous recherchez : ")
            req = c.execute("SELECT * FROM enseignant WHERE nomPrenom= ? ", (rechercher, ))
            if req != None:
                for row in req.fetchone():
                            print(row)
                numEnseign = int(input("Veuillez entrer l'ID de l'enseignant dont vous voulez faire un mise a jour  : "))
                c.execute("SELECT * FROM enseignant WHERE numEnseign=? ",(numEnseign, ))
                return numEnseign



 

#Méthode pour supprimer un enseignant
    def supprenseignant(): 
        numEnseign =enseignant.recheenseignant()
        print("est-ce ce l'enseignant que vous voulez supprimer ?  ")
        c.execute("SELECT * FROM enseignant  WHERE numEnseign = ?", (numEnseign, ))
        print(c.fetchone())
        c.execute(""" DELETE from enseignant WHERE numEnseign = ? """, (numEnseign, ))
        con.commit()
        print("supression réussie, veuillez vérifier ci-dessous.")
        c.close()
        con.close()


class groupe():

    def __init__(self,codeGroup,niveauGroup,nombreEtud,typeCours,designation,libeleModule):
        self.codeGroup = codeGroup
        self.niveauGroup = niveauGroup
        self.typeCours = typeCours
        self.designation = designation
        self.libeleModule = libeleModule
        self.nombreEtud = nombreEtud
       

    def affichegroupe():
        c.execute("SELECT * FROM groupe")
        print("Voici tous les Groupe")
        for resultat in c:
            print(resultat)

        m = menuapp.menu()

    def enreggroupe():
        designation = input("quel formation :")
        designation = designation.lower()
        libeleModule = input("nom du module: ")
        code = random.randint(0,1000)
        codeGroup = ("{}{}".format(designation[0:2],code))
        niveauGroup = input("Niveau du group :")
        nombreEtud = input("nombre d'etudiant  :")
        typeCours = input("type de cours(soiree ou jour ) :")

        
        c.execute(
            "INSERT INTO groupe (codeGroup,niveauGroup,nombreEtud,typeCours,designation,libeleModule) VALUES(?,?,?,?,?,?)",
            (codeGroup,niveauGroup,nombreEtud,typeCours,designation,libeleModule))
        con.commit()
        c.close()
        con.close()

#Méthode pour rechercher un enseignant
    def rechegroupe(): 
        rechercher = input("entrer le nom du Groupe a rechercher : ")
        c.execute("SELECT * FROM groupe WHERE codeGroup= ? ", (rechercher, ))
        print(c.fetchall())
        codeGroup = str(input("Veuillez entrer le code du groupe a rechercher : "))
        c.execute("SELECT * FROM groupe WHERE codeGroup=? ",(rechercher, ))
        return codeGroup


#Méthode pour supprimer un enseignant
    def supprgroupe(): 
        codeGroup = groupe.rechegroupe()
        print("est-ce ce le groupe que vous voulez supprimer ?  ")
        c.execute("SELECT * FROM groupe  WHERE codeGroup = ?", (codeGroup, ))
        print(c.fetchone())
        c.execute(""" DELETE from groupe WHERE codeGroup = ? """, (codeGroup, ))
        con.commit()
        print("supression réussie, veuillez vérifier ci-dessous.")
        c.close()
        con.close()

class abscence():

    def __init__(self,idAbs,heureAbs,Numetudiant,libeleModule,idSession):
        self.heureAbs = heureAbs
        self.Numetudiant = Numetudiant
        self.libeleModule = libeleModule
        self.idSession = idSession
       
    def enregabscence():
        heureAbs = input("entrez le nombre d'heure d'absence :")
        Numetudiant = input("entrez l'ID de l'etudiant : ")
        libeleModule = input("entrez le nom de module :")
        idSession = input("entrez L'ID de la session ) :")

        
        c.execute(
            "INSERT INTO abscence (heureAbs,Numetudiant,libeleModule,idSession) VALUES(?,?,?,?)",
            (heureAbs,Numetudiant,libeleModule,idSession))
        con.commit()
        c.close()
        con.close()

#Méthode pour rechercher une abscence
    def recheabscence(): 
        rechercher = input("entrer l'ID de l'etudiant abscent: ")
        c.execute("SELECT * FROM abscence WHERE Numetudiant= ? ", (rechercher, ))
        print(c.fetchall())
        # Numetudiant = str(input("Veuillez entrer le code du abscence a rechercher : "))
        # c.execute("SELECT * FROM abscence WHERE Numetudiant=? ",(rechercher, ))
        return rechercher

#Méthode pour supprimer un abscence
    def supprabscence(): 
        rechercher = abscence.recheabscence()
        print("est-ce ce l'etudiant abscent que vous voulez supprimer ?  ")
        c.execute("SELECT * FROM abscence  WHERE Numetudiant = ?", (rechercher, ))
        print(c.fetchone())
        c.execute(""" DELETE from abscence WHERE Numetudiant = ? """, (rechercher, ))
        con.commit()
        print("supression réussie, veuillez vérifier ci-dessous.")
        c.close()
        con.close()

class formation():

    def __init__(self,designation,dateFormation,heureDebut,heureFin,dureEnHeure,soldeHeure):
        self.designation = designation
        self.dateFormation = dateFormation
        self.heureDebut = heureDebut
        self.heureFin = heureFin
        self.dureEnHeure = dureEnHeure
        self.soldeHeure = soldeHeure

    def afficheformation():
        c.execute("SELECT * FROM formation")
        for resultat in c:
            print(resultat)

       
    def enregformation():
        designation = input("entrez le nom de la formation :")
        dateFormation = input("entrez la  date de debut de la formation : ")
        heureDebut = input("entrez l'huere de debut de la formation :")
        heureFin = input("entrez L'hure de fin de la formation :")
        dureEnHeure = input("entrez la duree en heure :")
        soldeHeure = input("entrez le nombre d'heure restant : ")

        
        c.execute(
            "INSERT INTO formation (designation,dateFormation,heureDebut,heureFin,dureEnHeure,soldeHeure) VALUES(?,?,?,?,?,?)",
            (designation,dateFormation,heureDebut,heureFin,dureEnHeure,soldeHeure))
        con.commit()
        c.close()
        con.close()
        print("ajout  reussie")
        m = menuapp.menu()

    def recheformation(): # méthode pour rechercher un formation
        rechercher = input("entrez le nom de la formation a rechercher : ")
        c.execute("SELECT * FROM formation WHERE designation= ? ", (rechercher, ))
        print(c.fetchall())
        # Numetudiant = str(input("Veuillez entrer le code du abscence a rechercher : "))
        # c.execute("SELECT * FROM abscence WHERE Numetudiant=? ",(rechercher, ))
        return rechercher

    def supprformation(): # méthode pour supprimer une formation
        rechercher = formation.recheformation()
        print("est-ce ce la formation que vous recherchez ?  ")
        c.execute("SELECT * FROM formation  WHERE designation = ?", (rechercher, ))
        print(c.fetchone())
        c.execute(""" DELETE from formation WHERE designation = ? """, (rechercher, ))
        con.commit()
        print("supression réussie, veuillez vérifier ci-dessous.")
        c.close()
        con.close()

        
class module():

    def __init__(self,libeleModule,volumeHorair,typeModule):
        self.libeleModule = libeleModule
        self.volumeHorair = volumeHorair
        self.typeModule = typeModule
       
    def affichemodule():
        c.execute("SELECT * FROM module")
        print("Voici la liste des Module")
        for resultat in c:
            print(resultat)
       
    def enregmodule():
        libeleModule = input("entrez le nom du module :")
        volumeHorair = input("entrez le volume horaire du module : ")
        typeModule = input("entrez le type du module : ")
        

        
        c.execute(
            "INSERT INTO module (libeleModule,volumeHorair,typeModule) VALUES(?,?,?)",
            (libeleModule,volumeHorair,typeModule))
        con.commit()
        c.close()
        con.close()

    def rechemodule(): # méthode pour rechercher un module
        rechercher = input("entrez le nom du module a rechercher : ")
        c.execute("SELECT * FROM module WHERE libeleModule= ? ", (rechercher, ))
        print(c.fetchall())
        # Numetudiant = str(input("Veuillez entrer le code du abscence a rechercher : "))
        # c.execute("SELECT * FROM abscence WHERE Numetudiant=? ",(rechercher, ))
        return rechercher

    def supprmodule(): # méthode pour supprimer un module
        rechercher = module.rechemodule()
        print("est-ce ce la module que vous recherchez ?  ")
        c.execute("SELECT * FROM module  WHERE libeleModule = ?", (rechercher, ))
        print(c.fetchone())
        c.execute(""" DELETE from module WHERE libeleModule = ? """, (rechercher, ))
        con.commit()
        print("supression réussie, veuillez vérifier ci-dessous.")
        c.close()
        con.close()


class sessionFormation():

    def __init__(self,idSession,libeleModule,dateSession,nomSale,codeGroup,heureDebut,heureFin,etudiantPresent,numEnseign):
        self.libeleModule = libeleModule
        self.dateSession = dateSession
        self.nomSale = nomSale
        self.codeGroup = codeGroup
        self.heureDebut = heureDebut
        self.heureFin = heureFin
        self.etudiantPresent = etudiantPresent
        self.numEnseign = numEnseign
       
    def affichesessionFormation():
        c.execute("SELECT * FROM sessionFormation")
        for resultat in c:
            print(resultat)
       
    def enregsessionFormation():
        libeleModule = input("entrez le nom de la session :")
        dateSession = input("entrez la date de session : ")
        nomSale = input("entrez le nom de la sale : ")
        codeGroup = input("entrez le code du Groupe: ")
        heureDebut = input("entrez l'huere de debut de la session : ")
        heureFin = input("entrez l'heure de fin de la session' : ")
        etudiantPresent = input("entrez le nombre etudiant present: ")
        numEnseign = input("entrez le numero de l'enseignant : ")
        

        
        c.execute(
            "INSERT INTO sessionFormation (libeleModule,dateSession,nomSale,codeGroup,heureDebut,heureFin,etudiantPresent,numEnseign) VALUES(?,?,?,?,?,?,?,?)",
            (libeleModule,dateSession,nomSale,codeGroup,heureDebut,heureFin,etudiantPresent,numEnseign))
        con.commit()
        c.close()
        con.close()

    def rechesessionFormation(): # méthode pour rechercher une sessionFormation
        rechercher = input("entrez le nom du sessionFormation a rechercher : ")
        c.execute("SELECT * FROM sessionFormation WHERE libeleModule= ? ", (rechercher, ))
        print(c.fetchall())
        # Numetudiant = str(input("Veuillez entrer le code du abscence a rechercher : "))
        # c.execute("SELECT * FROM abscence WHERE Numetudiant=? ",(rechercher, ))
        return rechercher

    def supprsessionFormation(): # méthode pour supprimer une sessionFormation
        rechercher = sessionFormation.rechesessionFormation()
        print("est-ce ce la session de Formation que vous recherchez ?  ")
        c.execute("SELECT * FROM sessionFormation  WHERE libeleModule = ?", (rechercher, ))
        print(c.fetchone())
        c.execute(""" DELETE from sessionFormation WHERE libeleModule = ? """, (rechercher, ))
        con.commit()
        print("supression réussie, veuillez vérifier ci-dessous.")
        c.close()
        con.close()


class menuapp(object):
    """cette classe est faite pour le menu"""

    def __init__(self,):
        super(menuapp, self).__init__()
        
        

    def menu():
        print(" voici les différentes options : ")
        print(" Option 1 ==> etudiant")
        print(" Option 2 ==> enseignant")
        print(" Option 3 ==> Formation")
        print(" Option 4 ==> Groupe")
        print(" Option 5 ==> Module")
        print(" Option 6 ==> Session")
        print(" Option 7 ==> Personne a Contacter")
        
        
        while True:
            option = int(input("Choisissez une option parmis celles ci-dessus. "))
            if option > 7:
                print ("Veuillez choisir parmi les options listées de 1 à 7")
                
            elif option == 1:
                print(" voici les différentes options : ")
                print(" Option 1 ==> modifier etudiant")
                print(" Option 2 ==> afficher tous les etudiant ")
                print(" Option 3 ==> rechercher un etudiant")
                print(" Option 4 ==> ajouter un etudiant")
                print(" Option 5 ==> supprimer un etudiant")
                while True:
                    option = int(input("Choisissez une option parmis celles ci-dessus. "))
                    if option > 5:
                        print ("Veuillez choisir parmi les options listées de 1 à 5")
                    elif option == 1:
                        etu = etudiant.modifetudiant()
                    elif option == 2:
                        etu = etudiant.afficheetudiant()
                    elif option == 3:
                        etu = etudiant.rechetudiant()
                    elif option == 4:
                        etu = etudiant.enregetudiant()
                    elif option == 5:
                        etu = etudiant.suppretudiant()

            elif option == 2:
                print(" voici les différentes options : ")
                print(" Option 1 ==> modifier un enseignant")
                print(" Option 2 ==> rechercher un enseignant ")
                print(" Option 3 ==> ajouter un enseignant ")
                print(" Option 4 ==> supprimer un enseignant ")
                print(" Option 5 ==> afficher tous les enseignant ")
                while True:
                    option = int(input("Choisissez une option parmis celles ci-dessus. "))
                    if option > 5:
                        print ("Veuillez choisir parmi les options listées de 1 à 5")
                    elif option == 1:
                        etu = enseignant.modifeignant()
                    elif option == 2:
                        etu = enseignant.recheenseignant()
                    elif option == 3:
                        etu = enseignant.enregenseignant()
                    elif option == 4:
                        etu = enseignant.supprenseignant()
                    elif option == 5:
                        etu = enseignant.afficheenseignant()
                    

            elif option == 3:
                print(" voici les différentes options : ")
                print(" Option 1 ==> rechercher une Formation")
                print(" Option 2 ==> ajouter une formation")
                print(" Option 3 ==> supprimer une formation")
                print(" Option 4 ==> afficher toutes les formation")
                while True:
                    option = int(input("Choisissez une option parmis celles ci-dessus. "))
                    if option > 4:
                        print ("Veuillez choisir parmi les options listées de 1 à 4")
                    elif option == 1:
                        etu = formation.recheformation()
                    elif option == 2:
                        etu = formation.enregformation()
                    elif option == 3:
                        etu = formation.supprformation()
                    elif option == 4:
                        etu = formation.afficheformation()

            elif option == 4:
                print(" voici les différentes options : ")
                print(" Option 1 ==> rechercher un Groupe")
                print(" Option 2 ==> ajouter un Groupe")
                print(" Option 3 ==> supprimer un Groupe")
                print(" Option 4 ==> afficher toutes les Groupe")
                while True:
                    option = int(input("Choisissez une option parmis celles ci-dessus. "))
                    if option > 4:
                        print ("Veuillez choisir parmi les options listées de 1 à 4")
                    elif option == 1:
                        etu = groupe.rechegroupe()
                    elif option == 2:
                        etu = groupe.enreggroupe()
                    elif option == 3:
                        etu = groupe.supprgroupe()
                    elif option == 4:
                        etu = groupe.affichegroupe()

            elif option == 5:
                print(" voici les différentes options : ")
                print(" Option 1 ==> rechercher un Module")
                print(" Option 2 ==> ajouter un Module")
                print(" Option 3 ==> supprimer un Module")
                print(" Option 4 ==> afficher toutes les Module")
                while True:
                    option = int(input("Choisissez une option parmis celles ci-dessus. "))
                    if option > 4:
                        print ("Veuillez choisir parmi les options listées de 1 à 4")
                    elif option == 1:
                        etu = module.rechemodule()
                    elif option == 2:
                        etu = module.enregmodule()
                    elif option == 3:
                        etu = module.supprmodule()
                    elif option == 4:
                        etu = module.affichemodule()

            elif option == 6:
                print(" voici les différentes options : ")
                print(" Option 1 ==> rechercher une Session")
                print(" Option 2 ==> ajouter une Session")
                print(" Option 3 ==> supprimer une Session")
                print(" Option 4 ==> afficher toutes les Sessions")
                while True:
                    option = int(input("Choisissez une option parmis celles ci-dessus. "))
                    if option > 4:
                        print ("Veuillez choisir parmi les options listées de 1 à 7")
                    elif option == 1:
                        etu = sessionFormation.rechesessionFormation()
                    elif option == 2:
                        etu = sessionFormation.enregsessionFormation()
                    elif option == 3:
                        etu = sessionFormation.supprsessionFormation()
                    elif option == 4:
                        etu = sessionFormation.affichesessionFormation()


            elif option == 7:
                print(" voici les différentes options : ")
                print(" Option 1 ==> rechercher une Personne a Contacter")
                print(" Option 2 ==> ajouter une Personne a Contacter")
                print(" Option 3 ==> supprimer une Personne a Contacter")
                print(" Option 4 ==> afficher toutes les Personne a Contacter")
                while True:
                    option = int(input("Choisissez une option parmis celles ci-dessus. "))
                    if option > 4:
                        print ("Veuillez choisir parmi les options listées de 1 à 4")
                    elif option == 1:
                        etu = personne.rechepersonne()
                    elif option == 2:
                        etu = personne.enregpersonne()
                    elif option == 3:
                        etu = personne.supprpersonne()
                    elif option == 4:
                        etu = personne.affichepersonne()




    

    
       
